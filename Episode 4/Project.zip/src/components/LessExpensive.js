import useRestList from "../../utils/Hooks/useRestList";
import DocContainer from "./DocContainer";
const LessExpensive=()=>{
    const resList=useRestList();
    const filtered=resList.filter((res)=>res?.info?.costForTwo.match(/(\d+)/)[0]<300)
    console.log(filtered);
    return(
        <div>
            <DocContainer restList={filtered}/>
        </div>
    )
}
export default LessExpensive;