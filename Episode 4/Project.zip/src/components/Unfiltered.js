import useRestList from "../../utils/Hooks/useRestList";
import DocContainer from "./DocContainer";
const Unfiltered=()=>{
    
    const list=useRestList();
    console.log("list inside unfiltered"+list)
    return(
        <DocContainer restList={list}/>
    )
}
export default Unfiltered;