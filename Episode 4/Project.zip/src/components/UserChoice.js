import DocContainer from "./DocContainer";
import useRestList from "../../utils/Hooks/useRestList";
 const UserChoice=()=>{
    
        // const resList=useRestList();
        // const filtered=resList.filter((res)=>res?.info?.)
        // console.log(filtered);
        // return(
        //     <div>
        //         <DocContainer restList={filtered}/>
        //     </div>
        // )
    
}
export default UserChoice;