import { Api } from "../../utils/constants";
import { Logo } from "../../utils/constants";
import { cart } from "../../utils/constants";
import { Link } from "react-router-dom";
const NavBar=()=>{
    return(
       <div className="flex justify-between items-center border border-black m-1 bg-slate-700">
            {/* <h1 className="m-4">hi i am styled using tailwind</h1>
            <h1 className="m-10">hi i am styled using tailwind</h1> */}
            <div><img src={Logo} className="w-32 m-2"/></div>
            <div>
                <ul className="flex p-4 m-4"> 
                    <Link to="/" className="m-3">Home</Link>
                    <Link to="/about" className="m-3">About</Link>
                    <Link to="/contact" className="m-3">Contact</Link>
                    
                    <li><img src={cart} className="w-12"/></li>
                </ul>
            </div>
       </div>
    )
}
export default NavBar;