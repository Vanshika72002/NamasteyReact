const MenuCard=(props)=>{
    const {menuData}=props;
    return(
        <>
            <div><h1 className="font-bold text-lg">{menuData?.card?.info?.name}</h1>
            </div> 
            <div className="grid grid-cols-[70%_30%] border-b-2">
                <div>{console.log(menuData?.card?.info)}
                    <h2>Rs.{menuData?.card?.info?.price/100}</h2>
                    <h2>{menuData?.card?.info?.description}</h2>
                </div>
                <div className="p-1">
                    <img src={"https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_1024/"+menuData?.card?.info?.imageId} className="w-30 h-30"/>
                </div>
                                        
            </div>
        </>
    )
}
export default MenuCard;