const Footer=()=>{
    return(
        <div className="border border-black m-1" >
            
            <h1 className="from-neutral-100">This is footer</h1>
            
        </div>
    )
}
export default Footer;