import { useEffect ,useState} from "react";
import { Api } from "../../utils/constants";
import ResCard from "./ResCard";
import { list } from "postcss";
import { Filter } from "./Filter";
import Shimmer from "./Shimmer";
import useRestList from "../../utils/Hooks/useRestList";
import { Link } from "react-router-dom";

const ResContainer=(props)=>{
    const list=props.restList;
    console.log("list==")
    console.log(list);
    return list.length===0?<Shimmer/>:(
        <div>
        <Filter/>
        <div className="flex border border-black  m-1 flex-wrap">
            {list.map((restaurant)=>(<Link to={"/restaurants/"+restaurant.info.id} key={restaurant.info.id}><ResCard resData={restaurant} /></Link>))}
        </div>
        </div>
    );
};
export default ResContainer;
// https://www.swiggy.com/dapi/menu/pl?page-type=REGULAR_MENU&complete-menu=true&lat=28.6906285&lng=77.2764329&restaurantId=378093&catalog_qa=undefined&submitAction=ENTER
//Menu api