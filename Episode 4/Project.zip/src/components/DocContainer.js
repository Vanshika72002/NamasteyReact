import { useEffect ,useState} from "react";
import { Api } from "../../utils/constants";
import DocCard from "./DocCard";
import { list } from "postcss";
import { Filter } from "./Filter";
import Shimmer from "./Shimmer";
import useRestList from "../../utils/Hooks/useRestList";
import { Link } from "react-router-dom";

const DocContainer=(props)=>{
    const list=props.restList;
    console.log("list==")
    console.log(list);
    return list.length===0?<Shimmer/>:(
        <div>
        <Filter/>
        <div className="flex border border-black  m-1 flex-wrap">
            {list.map((restaurant)=>( <DocCard key={restaurant.info.id} resData={restaurant} /> ))}
        </div>
        </div>
    );
};
export default DocContainer;