import useRestList from "../../utils/Hooks/useRestList";
// import DocContainer from "./DocContainer";
import DocContainer from "./DocContainer";
const Range=()=>{
    const resList=useRestList();
    const filtered=resList.filter((res)=>(res?.info?.costForTwo.match(/(\d+)/)[0]>300&&res?.info?.costForTwo.match(/(\d+)/)[0]<600))
    return(
        <div>
            <DocContainer restList={filtered}/>
        </div>
    )
}
export default Range;