import React from "react";
import ReactDOM from "react-dom/client";
import NavBar from "../src/components/NavBar";
import Footer from "../src/components/Footer";
import ResContainer from "../src/components/ResContainer";
import {Filter} from "../src/components/Filter";
import AppRouter from "../src/components/AppRouter";
import { RouterProvider } from "react-router-dom";
// const El=()=>{
//     return(
//         <div>
//             <NavBar/>
//             <Filter/>
//             <ResContainer/>
//             <Footer/>
//         </div>
//     )
// }
const root=ReactDOM.createRoot(document.getElementById("root"));
root.render(<RouterProvider router={AppRouter}/>);