export const Api="https://www.swiggy.com/dapi/restaurants/list/v5?lat=28.6906285&lng=77.2764329&is-seo-homepage-enabled=true&page_type=DESKTOP_WEB_LISTING";
export const Logo="https://img.freepik.com/premium-vector/good-food-logo-template_79169-17.jpg?w=2000";
export const cart="https://static.vecteezy.com/system/resources/thumbnails/004/798/846/small/shopping-cart-logo-or-icon-design-vector.jpg"
export const imgurl="https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_660/";
export const menu_api="https://www.swiggy.com/dapi/menu/pl?page-type=REGULAR_MENU&complete-menu=true&lat=28.6906285&lng=77.2764329&restaurantId=";