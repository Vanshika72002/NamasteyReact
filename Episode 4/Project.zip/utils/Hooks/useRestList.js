import { Api } from "../constants"
import { useEffect,useState } from "react"
const useRestList=()=>{

    const [RestList,setRestList]=useState([]);
   
    useEffect(()=>{
        console.log("useEffect called");
        fetchData();
        console.log("data fetched");
    },[]);
    const fetchData=async()=>{
        const data=await fetch("https://www.swiggy.com/dapi/restaurants/list/v5?lat=28.6906285&lng=77.2764329&is-seo-homepage-enabled=true&page_type=DESKTOP_WEB_LISTING");
        const Json=await data.json();
        console.log("inside hook");
        console.log(Json);
        // console.log(Json.data.cards[4].card.card.gridElements.infoWithStyle.restaurants)
        // console.log(Json?.data);
        
        console.log(Json?.data?.cards[5].card.card);
        // console.log(Json?.data?.cards[5]?.card)
        // console.log(Json?.data?.cards[5]?.card?.card?.gridElements);
        setRestList(Json?.data?.cards[5]?.card?.card?.gridElements?.infoWithStyle?.restaurants);
    };
    return RestList;
}
export default useRestList;