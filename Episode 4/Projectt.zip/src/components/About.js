const About=()=>{
    return(
        <h1>this is about</h1>
    )
}
export default About;