//Displaying restaurants with 4.0+ rating
import { useState } from "react";
import useRestList from "../../utils/Hooks/useRestList";
import ResContainer from "./ResContainer";
export const Top=()=>{
    const list=useRestList();
    console.log(list);
    const filtered=list.filter((res)=>res?.info?.avgRating>4);
    console.log(filtered);
    return(
        <ResContainer restList={filtered}/>
   );
}