const ShimmerCard=()=>{
    return(
        <h1>this is shimmer card</h1>
    )
}
export default ShimmerCard;