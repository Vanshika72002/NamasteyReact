import { createBrowserRouter } from "react-router-dom";
import { RouterProvider } from "react-router-dom";
import ResContainer from "./ResContainer";
import About from "./About";
import Contact from "./Contact";
import { Top } from "./Top";
import AppLayout from "./AppLayout";
import Unfiltered from "./Unfiltered";
import FastDelivery from "./FastDelivery";
import LessExpensive from "./LessExpensive";
import Range from "./Range";
import UserChoice from "./UserChoice";
import Menu from "./Menu";
import RestMenu from "./RestMenu";
const AppRouter=createBrowserRouter([
    {
        path:"/",
        element:<AppLayout/>,
        children:[
            {
                path:"/",
                element:<Unfiltered/>
            },
            {
                path:"/about",
                element:<About/>
            },
            {
                path:"/contact",
                element:<Contact/>
            },
            {
                path:"/Top",
                element:<Top/>
            },
            {
                path:"/FastDelivery",
                element:<FastDelivery/>
            },
            {
                path:"/LessThan300",
                element:<LessExpensive/>
            },
            {
                path:"/between300and600",
                element:<Range/>
            },
            {
                path:"/userChoice",
                element:<UserChoice/>
            },
            {
                path:"/restaurants/:id",
                element:<Menu/>
            },
            {
                path:"/restmenu",
                element:<RestMenu/>
            }
        ]
    }
]);
export default AppRouter;