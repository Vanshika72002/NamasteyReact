import useRestList from "../../utils/Hooks/useRestList";
import ResContainer from "./ResContainer";
const Unfiltered=()=>{
    
    const list=useRestList();
    console.log("list inside unfiltered"+list)
    return(
        <ResContainer restList={list}/>
    )
}
export default Unfiltered;